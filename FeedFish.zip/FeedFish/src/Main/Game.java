package Main;

import javax.swing.*;

public class Game {
    public static void main(String[] args) {
        JFrame window = new JFrame("FeedFish");
        Gamepanel gamepanel= new Gamepanel();
        window.setSize(540,500);
        window.setResizable(false);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setContentPane(gamepanel);
        window.setLayout(null);
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }
}
